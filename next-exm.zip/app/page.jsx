'use client'

import { ShopDiamondShape } from "./homePage/page";



export default function Home() {
  return <ShopDiamondShape />;
}
